// function logon(zh,pwd){
// var success;
// if (zh == "peter" && pwd == "123") {
//     success = true;//登陆成功
// }else{
//     success = false;
// }
// return  success; 
// }
var times = 3;//三次机会
//三次验证
function logon(zh, pwd) {
    if (zh == "peter" && pwd == "123" && times > 0) {
        window.location.href = '主页.html';
    } else if (times <= 0) {
        document.getElementById('hint').innerHTML = '三次登录失败，禁止再次登录';
    } else {
        times--;
        document.getElementById('hint').innerHTML = '账号或密码错误，还有' + times + '次机会';
    }
}