window.onload = function(){
    //获取用户名的输入框元素
   var username = document.getElementById("username");
    var warn = document.getElementById("warn");
    //添加此元素的onblur事件
    username.onblur = function(){
        //判断其值是否为数字，且数字长度为11位
        console.log("用户名："+username.value);
        if (username.value.length == 11 && !isNaN(username.value)){
            warn.innerText = "符合要求";  
        }else {
            warn.innerText = "非法输入";
        }
    }
}