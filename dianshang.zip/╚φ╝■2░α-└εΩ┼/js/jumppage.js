"use strict"// 严格模式
//1 翻页功能的实现
//1.1 获取滑动容器宽度
var get_scroll = document.querySelector("#scroll");
// chientWidth属性是专门用来获取当前元素在当前html页面中的css宽度
var s_width = get_scroll.clientWidth;

//2 设置初始图片的位置
var imgs = document.querySelectorAll('#scroll>img');
for (var index = 0; index < imgs.length; index++) {
    imgs[index].style.left = index * s_width + 'px';
}
//3 显示页码
for (var index = 0; index < imgs.length - 1; index++) {
     var div = document.createElement('div');
    get_scroll.appendChild(div);
    div.classList.add('pageControl');
    div.style.top = '80%';
    div.style.left = (s_width/2 + index * 20) - ((imgs.length-1)*10 + (imgs.length-1-1)*10)/2 + 'px';
}
//4获取页对应元素
var pageControl = document.querySelectorAll('.pageControl');
//4.4 给node节点对象集合扩充的一个方法  作用是初始化页码样式
pageControl.setPage = function(p){
    p = p - 1;
    for (var index = 0; index < array.length; index++) {
        this[index].style.backgroundColor = '';
    }
    this[p].style.backgroundColor = '#fff';
}
//4.2  移动功能
function move() {
     for (var index = 0; index < imgs.length; index++) {
        imgs[index].style.left =  (index - page + 1) * s_width + 'px';
     }
     pageControl.setPage(page);
}
//4.1 DOM级事件绑定
for (var index = 0; index < pageControl.length; index++){
    //因要区分每一个div身份所有为div增加一个index属性
    pageControl[index].index = index;
    pageControl[index].onclick = function (e) {
        //改变page
        page = e.target.index + 1;
        //移动
        move();
    };
}
function move(){
    //根据当前page 去改变每一个img的left
    for (var  index = 0; index < imgs.length; index++) {
        //根据当前也显示计算出每一张图片的位置
        imgs[index].style.left = s_width *(index - page) + 'px';
    }
    //要在移动中定时判断当前是不是最后一张
    setTimeout(function () {
        if (page == imgs.length - 1){
            page = 0 ;
            //再把所有的img动画取消
            //因为回到第一张不需要动画
            for (var index = 0; index < imgs.length; index++) {
                imgs[index].style.transition = 'none';
            }
            //把所有的图片回归到初始位置
            for (var  index = 0; index < imgs.length; index++) {
                imgs[index].style.left = s_width *(index - page) + 'px';
            }
            //回归之后设置动画过渡属性
            //如果不延迟就会立刻赋值，导致刷新界面的时候就已经有了过渡属性，导致回来的时候就看到动画了
            setTimeout(function () {
                for (var index = 0; index < imgs.length; index++) {
                    imgs[index].style.transition = 'left 0.7s ease-in-out';
                }
            },100);
        }
    },700);//transition: left 0.7s ease-in-out;
}
var page = 1;
//4.5 初始化page
pageControl.setPage(page);